///////////////////////////////////////////////////////////////////////////////
//               Nuevos constructores de variables let y const               //
///////////////////////////////////////////////////////////////////////////////

console.log('nombre:', nombre); // Santiago

// Se declara la variable "nombre" y se le asigna un valor
var nombre = 'Juan';
console.log('nombre:', nombre); // Juan

// Se vuelve a declarar la variable "nombre", lo cual no produce ningún error
var nombre = 'Marcelo';
console.log('nombre:', nombre); // Marcelo


var codigoDeLaPersona = 47;

console.log('codigoDeLaPersona:', codigoDeLaPersona);   // 47

// Debido a un "error de tipeo"; se genera una NUEVA variable sin querer
codigoDLaPersona = 33;  // <-- error de tipeo!
console.log('codigoDeLaPersona:', codigoDeLaPersona);   // 47


console.log('ciudad:', ciudad); // Buenos Aires     <-- atención, ya existí de antes! (archivo HTML)
var ciudad = 'La Plata';    // Se está, "supuestamente", creando una nueva variable, pero no es así
console.log('ciudad:', ciudad); // La Plata


// Se declara una variable de nombre "color" con el constructor de variables "let" y se le asigna un valor
let color = 'azul';
console.log('color:', color);   // azul

// Si se intenta volver a declarar una variable que fue previamente declarada
// con el constructor "let" o "const", se produce un error de sintaxis
// let color = 'violeta';
// var color = 'violeta';
// const color = 'violeta';
color = 'violeta';
console.log('color:', color);   // violeta

// let nombre = 'Martina';

// Se declara una variable de nombre "pais" con el constructor de variables "const" y se le asigna un valor
const pais = 'Argentina';
console.log('pais:', pais);     // Argentina


// Si se intenta volver a declarar una variable que fue previamente declarada
// con el constructor "let" o "const", se produce un error de sintaxis
// const pais = 'Brasil';       // Uncaught SyntaxError: Identifier 'pais' has already been declared

// Las variables constantes son "constantes" ;)
// No se les puede volver a asignar otro valor
// pais = 'Brasil';                // Uncaught TypeError: Assignment to constant variable.
console.log('pais:', pais);         // Argentina

// Las variables creadas con var y sin ninguna palabra (var/let/const), pasan a
// convertirse en propiedades del objeto window
x = 10;
var y = 20;
z = 30;

console.log(x);
console.log(y);
console.log(z);

console.log(window.x);  // 10
console.log(window.y);  // 20
console.log(window.z);  // 30

// Las variables creadas con los constructores let o const,
// no se transforman en propiedades del objeto window
let m = 100;
const n = 200;

console.log(m);
console.log(n);

console.log(window.m);  // undefined
console.log(window.n);  // undefined



////////////////////////////////////////////////////////////////////////////////
//                     Arrow functions / Funciones flecha                     //
////////////////////////////////////////////////////////////////////////////////

// Formas de crear funciones antes de ES6 (y ahora también)

// Forma declarativa
function saludar1() {
    console.log('Hola 1!');
}

// Forma expresiva (función anónima)
var saludar2 = function () {
    console.log('Hola 2!');
};

saludar1();
saludar2();

console.log('-------------------------------------');
console.log(typeof saludar1);           // function
console.log(typeof saludar2);           // function
console.log('-------------------------------------');


console.log('Hola', typeof 'Hola');     // string
console.log('123', typeof '123');      // string
console.log(444, typeof 444);        // number     
console.log(55555.18, typeof 55555.18);   // number         
console.log(true, typeof true);       // boolean
console.log(false, typeof false);      // boolean


var prueba1 = 'Texto';
var prueba2 = 40;
var prueba3 = [100, 200, 300];
var prueba4 = function () { console.log('Prueba 4'); };

console.log('prueba1:', typeof prueba1);    // string
console.log('prueba2:', typeof prueba2);    // number
console.log('prueba3:', typeof prueba3);    // object
console.log('prueba4:', typeof prueba4);    // function

// if (typeof prueba1 === 'string') {
//     console.log('Prueba 1 es un string');
// } else {
//     console.log('Prueba 1 No es un string');
// }



// Formas de crear funciones a partir de ES6:
let saludar3 = function () {
    console.log('Hola 3!');
};

const saludar4 = function () {
    console.log('Hola 4!');
};

saludar3();

saludar3 = 40;
// saludar3();     // Uncaught TypeError: saludar3 is not a function


saludar4();

// saludar4 = 50;      // Uncaught TypeError: Assignment to constant variable.

