////////////////////////////////////////////////////////////////////////////////
//                     Arrow functions / Funciones flecha                     //
////////////////////////////////////////////////////////////////////////////////

// Formas de crear funciones a partir de ES6:
// Forma expresiva, asignando una función anónima a una variable declarada con let o const
// retorna a * b
let getSuma = function (a, b) {
    return a + b;
};

const resultado1 = getSuma(10, 30);
console.log('resultado1:', resultado1);

const resultado2 = getSuma(10, 30);
console.warn('resultado2:', resultado2);

// const resultado3 = getSuma(10, 30);
// alert('resultado3:', resultado3);

console.log('suma de 10 + 30:', getSuma(10, 30));

const resultado4 = getSuma(10, 30);
const resultado5 = getSuma(10, 30);
getSuma(10, 30);
getSuma(10, 30);
getSuma(10, 30);
getSuma(10, 30);

console.log('#########################################');

// retorna 'ok' (porque sí)
const multiplicar = function (a, b) {
    const total = a * b;
    console.warn(a + 'x' + b + ' = ' + total);
    return 'ok';
};

const resultadoMultiplicacion1 = multiplicar(10, 2);
console.log('resultadoMultiplicacion1:', resultadoMultiplicacion1);

console.log('ok');
console.log('ok');
console.log('ok');
console.log(multiplicar(1000, 20));


console.log('#########################################');



// retorna undefined
const dividir = function (a, b) {
    const resultadoDivision = a / b;
    console.error(a + '/' + b + ' = ' + resultadoDivision);
    // return undefined;    // Si una función no retorna "nada", implícitamente, es como si retornase undefined
};

dividir(12, 2);
dividir(12, 2);
dividir(12, 2);
const resultadoDivision1 = dividir(12, 3);
console.log('resultadoDivision1:', resultadoDivision1); // undefined

console.log('División de 12/3:', dividir(12, 3)); // undefined



console.log('#####################################');


const imprimirSaludo = function () {
    return console.log('#### Hola! ####');
};

imprimirSaludo();
imprimirSaludo();
imprimirSaludo();
imprimirSaludo();
const resultadoSaludo = imprimirSaludo();
console.log('resultadoSaludo:', resultadoSaludo);

imprimirSaludo();



console.log('/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*');
console.log('/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*');
console.log('/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*');



// Arrow functions (funciones flecha)

// Forma declarativa
// function imprimirHora() {
//     const horaActual = new Date().toLocaleTimeString();
//     console.log('⌚' + horaActual);
// }

// Forma expresiva, mediante una función anónima
// const imprimirHora = function () {
//     const horaActual = new Date().toLocaleTimeString();
//     console.log('⌚' + horaActual);
// };


// Forma expresiva, mediante una arrow function
const imprimirHora = () => {
    const horaActual = new Date().toLocaleTimeString();
    console.log('⌚' + horaActual);
};

imprimirHora();


const imprimirNombreCompleto = (nombre, apellido) => {
    const nombreCompleto = nombre + ' ' + apellido;
    console.log(nombreCompleto);
};

imprimirNombreCompleto('Luciana', 'Moretti');
imprimirNombreCompleto('Gastón', 'Perales');
console.log('---');


// const getPi = function () {
//     return Math.PI;
// };

// const getPi = () => {
//     return Math.PI;
// };

// const getPi = () => { return Math.PI; };

// const getPi =  => Math.PI;          // Uncaught SyntaxError: Unexpected token '=>'
const getPi = () => Math.PI;

console.log(getPi());
console.log(getPi());
console.log(getPi());


// const getNombreCompleto = (nombre, apellido) => {
//     return nombre + ' ' + apellido;
// };

// const getNombreCompleto = (nombre, apellido) => { return nombre + ' ' + apellido; };

const getNombreCompleto = (nombre, apellido) => nombre + ' ' + apellido;

const persona1 = getNombreCompleto('Viviana', 'Pascual');
console.log('Persona n°1:', persona1);

console.log('Persona n°2:', getNombreCompleto('Andrés', 'Monzón'));

getNombreCompleto('Pablo', 'Torres');
getNombreCompleto('Carolina', 'González');
getNombreCompleto('Micaela', 'Sánchez');

console.log('---');



// const getPotencia = function (base, exponente) {
//     return base ** exponente;
// };

// const getPotencia = function (base, exponente) { return base ** exponente; };

// const getPotencia = (base, exponente) => { return base ** exponente; };

// const getPotencia = base, exponente => base ** exponente;   //  Uncaught SyntaxError: Missing initializer in const declaration
const getPotencia = (base, exponente) => base ** exponente;

console.log(getPotencia(2, 3));


// const getCuadrado = function (numero) {
//     return getPotencia(numero, 2);
// };

// const getCuadrado = (numero) => {
//     return getPotencia(numero, 2);
// };

// const getCuadrado = (numero) => { return getPotencia(numero, 2); };

// const getCuadrado = (numero) => getPotencia(numero, 2);

const getCuadrado = numero => getPotencia(numero, 2);

console.log(getCuadrado(3));


// const pasarAMayusculas = function (texto) {
//     return texto.toUpperCase();
// };

// const pasarAMayusculas = (texto) => {
//     return texto.toUpperCase();
// };

// const pasarAMayusculas = (texto) => { return texto.toUpperCase(); };

// const pasarAMayusculas = texto => { return texto.toUpperCase(); };

const pasarAMayusculas = texto => texto.toUpperCase();

console.log(pasarAMayusculas('Hola! Qué tal?'));


const get4 = () => 4;

console.log(get4());
const cuatro = get4();
console.log(cuatro);


// console.log(getPotencia(       25           ,    cuatro              ));
// console.log(getPotencia(       25           ,    getSuma(  4,   0)   ));
// console.log(getPotencia(   getCuadrado(5)   ,    getSuma(  4,   0)   ));
// console.log(getPotencia(       25           ,    3 + 1               ));
// console.log(getPotencia(       25           ,     4                  ));

console.log(getPotencia(25, cuatro));
console.log(getPotencia(25, getSuma(4, 0)));
console.log(getPotencia(getCuadrado(5), getSuma(4, 0)));
console.log(getPotencia(25, 3 + 1));
console.log(getPotencia(25, 4));


// const dejarHuellas = function () { console.log('🐾🐾🐾'); };
// const dejarHuellas = () => { console.log('🐾🐾🐾'); };
const dejarHuellas = () => console.log('🐾🐾🐾');

dejarHuellas();
dejarHuellas();
dejarHuellas();
const indefinida = dejarHuellas();
console.log('indefinida:', indefinida);

