////////////////////////////////////////////////////////////////////////////////
//                          Pruebas scope de función                          //
////////////////////////////////////////////////////////////////////////////////

let cantidadDeSumas = 0;

function sumar (a, b) {
    // cantidadDeSumas = 100;
    // var cantidadDeSumas = 100;
    // let cantidadDeSumas = 100;
    // const cantidadDeSumas = 100;
    cantidadDeSumas++;
    console.log('Cantidad de sumas hasta el momento: ' + cantidadDeSumas);
    const total = a + b;
    return total;
}

console.warn('>>>>> Sumas realizadas: ', cantidadDeSumas); // 0

console.log(sumar(10, 2));           // 12
console.log(sumar(20, 18.3));        // 38.3
console.log(sumar(1, 200));          // 201
console.warn('>>>>> Sumas realizadas: ', cantidadDeSumas); // 3
console.log(sumar(0, -4));           // -4
console.log('____');
console.warn('>>>>> Sumas realizadas: ', cantidadDeSumas); // 3

// console.log(a);      // main.js:7 Uncaught ReferenceError: a is not defined
// console.log(b);      // main.js:7 Uncaught ReferenceError: b is not defined
// console.log(total);  // main.js:7 Uncaught ReferenceError: total is not defined

const a = 10;
console.log(a);         // 10


const total = 10 * 4;
console.log(total);     // 40


function probarScope() {
    var pruebaVar = 1;
    let pruebaLet = 2;
    const pruebaConst = 3;
    let abc = 200;
    xyz = 777;      // global!
    console.log('Dentro de la función probarScope:');
    console.log('> pruebaVar:', pruebaVar);
    console.log('> pruebaLet:', pruebaLet);
    console.log('> pruebaConst:', pruebaConst);
    console.log('> abc:', abc);
    console.log('> xyz:', xyz);
}


// console.log(abc);            // Uncaught ReferenceError: abc is not defined
// console.log(xyz);            // Uncaught ReferenceError: xyz is not defined
probarScope();
// console.log(abc);            // Uncaught ReferenceError: abc is not defined
console.log(xyz);               // 777

// console.log('Fuera de la función probarScope:');
// console.log('> pruebaVar:', pruebaVar);     // Uncaught ReferenceError: pruebaVar is not defined
// console.log('> pruebaLet:', pruebaLet); // Uncaught ReferenceError: pruebaLet is not defined
// console.log('> pruebaConst:', pruebaConst); // Uncaught ReferenceError: pruebaConst is not defined



////////////////////////////////////////////////////////////////////////////////
//                          Pruebas scopes de bloque                          //
////////////////////////////////////////////////////////////////////////////////

console.log('\n\n##################\n\n\n');

// Bloque condicional
if (true) {
    var pruebaScopeBloqueCondicionalVar = 100;
    let pruebaScopeBloqueCondicionalLet = 200;
    const pruebaScopeBloqueCondicionalConst = 300;
    console.log('Dentro debloquel scope de :');
    console.log('> pruebaScopeBloqueCondicionalVar:', pruebaScopeBloqueCondicionalVar);
    console.log('> pruebaScopeBloqueCondicionalLet:', pruebaScopeBloqueCondicionalLet);
    console.log('> pruebaScopeBloqueCondicionalConst:', pruebaScopeBloqueCondicionalConst);
}

console.log('Fuera debloquel scope de :');
console.log('> pruebaScopeBloqueCondicionalVar:', pruebaScopeBloqueCondicionalVar);
// console.log('> pruebaScopeBloqueCondicionalLet:', pruebaScopeBloqueCondicionalLet);           // Uncaught ReferenceError: pruebaScopeBloqueCondicionalLet is not defined
// console.log('> pruebaScopeBloqueCondicionalConst:', pruebaScopeBloqueCondicionalConst);       // Uncaught ReferenceError: pruebaScopeBloqueCondicionalConst is not defined

console.log('---');


// Bloque repetitivo while
let iWhile = 0;
while (iWhile < 5) {
    var pruebaScopeWhileVar = 10000;
    let pruebaScopeWhileLet = 20000;
    const pruebaScopeWhileConst = 30000;
    console.log(iWhile);
    iWhile++;
}

console.log(pruebaScopeWhileVar);           // 10000
// console.log(pruebaScopeWhileLet);        // Uncaught ReferenceError: pruebaScopeWhileLet is not defined
// console.log(pruebaScopeWhileConst);      // Uncaught ReferenceError: pruebaScopeWhileConst is not defined
console.log(iWhile);                        // 5

console.log('---');


// Bloque repetitivo for
for (let iFor = 0; iFor < 5; iFor++) {
    var pruebaScopeWhileVar = 10000;
    let pruebaScopeWhileLet = 20000;
    const pruebaScopeWhileConst = 30000;
    console.log(iFor);
}

console.log(pruebaScopeWhileVar);           // 10000
// console.log(pruebaScopeWhileLet);        // Uncaught ReferenceError: pruebaScopeWhileLet is not defined
// console.log(pruebaScopeWhileConst);      // Uncaught ReferenceError: pruebaScopeWhileConst is not defined
// console.log(iFor);                       // Uncaught ReferenceError: iFor is not defined

console.log('---');

// Bloque anónimo (se ejecuta solo)
console.log('AAA');
console.log('BBB');
console.log('CCC');
{
    console.log('...');
    var pruebaScopeAnonimoVar = 111;
    let pruebaScopeAnonimoLet = 222;
    const pruebaScopeAnonimoConst = 333;
    console.log('...');
}
console.log('DDD');
console.log('EEE');
console.log('FFF');

console.log('pruebaScopeAnonimoVar:', pruebaScopeAnonimoVar);              // 111
// console.log('pruebaScopeAnonimoLet:', pruebaScopeAnonimoLet);           // Uncaught ReferenceError: pruebaScopeAnonimoLet is not defined
// console.log('pruebaScopeAnonimoConst:', pruebaScopeAnonimoConst);       // Uncaught ReferenceError: pruebaScopeAnonimoConst is not defined

{
    let nombreAplicacion = 'Mi producto!';
    console.log(nombreAplicacion);
    document.querySelector('h1').innerHTML = nombreAplicacion;
}
console.log(nombreAplicacion); // viene de archivo js/otro.js


// IIFE: immediately invoked function expression
(function () {
    console.error('yo hago cosas');
})();

// x();
// console.log(x)