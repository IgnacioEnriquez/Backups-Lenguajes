let nombreAplicacion = 'Probando probando 123 v1.2';
console.log('### ' + nombreAplicacion + '###');
