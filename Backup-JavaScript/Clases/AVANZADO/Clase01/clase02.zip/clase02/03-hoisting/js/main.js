
var a = 100;
console.log(a);


// console.log(b);  // Uncaught ReferenceError: b is not defined
console.log(c);     // undefined

var c = 300;


console.log('///////////////////');


console.log(d);     // undefined
var d;

d = 'abc';
console.log(d);     // 'abc'

d = 8000;
console.log(d);     // 8000



console.log('///////////////////');


console.log(e);     // undefined
var e = 'eeeeeee';
// var e;
// e = 'eeeeeee';

console.log(e);     // 'eeeeeee'


console.log('///////////////////');

// console.log(x);  // Uncaught ReferenceError: x is not defined
console.log(y);     // undefined
// console.log(z1);    // Uncaught ReferenceError: Cannot access 'z1' before initialization
// console.log(z2);    // Uncaught ReferenceError: Cannot access 'z2' before initialization

var y = 'i griega';
let z1 = 'zeta 1';
const z2 = 'zeta 2';


console.log(sumar1);    // ƒ sumar1 (a, b) { return a + b; }
console.log(sumar1(100, 200));                  // ok
function sumar1 (a, b) { return a + b; }
console.log(sumar1(100, 200));                  // ok


console.log(sumar2);    // undefined
// console.log(sumar2(10000, 20000));           // Uncaught TypeError: sumar2 is not a function
var sumar2 = function (a, b) { return a + b; };
console.log(sumar2(10000, 20000));              // ok


// sumar3(1, 2);                                // Uncaught ReferenceError: Cannot access 'sumar3' before initialization
const sumar3 = function (a, b) { return a + b; };
sumar3(1, 2);                                   // ok

