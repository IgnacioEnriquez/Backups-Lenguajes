
const xhr = new XMLHttpRequest();
xhr.open('get', 'https://jsonplaceholder.typicode.com/posts');
xhr.send();
xhr.addEventListener('load', e => {
    if (e.target.status === 200) {
        let response = e.target.responseText;
        // console.log('typeof response:', typeof response);               // string
        // console.log('response:', response);
        
        // response = '{"a": 1, "b": 2, "c": 3, "color": "rojo"}';
        // response = '{"a": 1, b ...  ESTE TEXTO NO ES VÁLIDO PARA JSON, "c": 3, "color": "rojo"}';
        // console.log(response);
        // const objetoRecreado = JSON.parse(response)
        // console.log('objetoRecreado:', objetoRecreado);
        // const contentType = e.target.getResponseHeader('content-type');
        // console.log('contentType:', contentType);                       // application/json; charset=utf-8

        /*
        if (contentType.includes('application/json')) {
            const posts = JSON.parse(response);
            console.log('typeof posts:', typeof posts);                     // object
            console.log('posts:', posts);
        }
        */



        try {
            const posts = JSON.parse(response);
            // console.log('typeof posts:', typeof posts);                     // object
            // console.log('posts:', posts);
            const postCero = posts[0];
            // console.log('postCero:', postCero);
            console.log('postCero.userId:\n', postCero.userId);
            console.log('postCero.id:\n', postCero.id);
            console.log('postCero.title:\n', postCero.title);
            console.log('postCero.body:\n', postCero.body);
        } catch (error) {
            // console.dir(error);
            console.log('Error en la conversión:', error.message);
            // console.log('Stack', error.stack);
        }

    }
});

