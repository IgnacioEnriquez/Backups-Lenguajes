
const xhr = new XMLHttpRequest();
xhr.open('get', 'https://jsonplaceholder.typicode.com/posts');
xhr.send();
xhr.addEventListener('load', e => {
    if (e.target.status === 200) {
        let response = e.target.responseText;

        try {
            const posts = JSON.parse(response);
            for (let post of posts) {
                console.warn(`POST #${post.id}`);
                // console.group(`POST #${post.id}`);
                // console.groupCollapsed(`POST #${post.id}`);
                // console.log('Title:', post.title);
                // console.log('Body:', post.body);
                console.log(`%cTitle: %c${post.title}`, 'font-size: 14px; font-weight: bold;', 'color: cyan;');
                console.log(`%cBody: %c${post.body}`, 'font-size: 14px; font-weight: bold;', 'color: cyan;');
                // console.groupEnd();
            }
        } catch (error) {
            // console.dir(error);
            console.log('Error en la conversión:', error.message);
        }

    }
});
