const btnGetPost = document.querySelector('.btn-get-post');
const inputIdPost = document.getElementById('id-post');

const articlePost = document.querySelector('.article-post');
const articleTitle = document.querySelector('.article-post__title');
const articleBody = document.querySelector('.article-post__body');
const articleUserId = document.querySelector('.article-post__user-id');

inputIdPost.addEventListener('input', e => {
    if (e.target.value && e.target.value !== '0') {
        btnGetPost.disabled = false;
    } else {
        btnGetPost.disabled = true;
    }
});

btnGetPost.addEventListener('click', e => {
    articlePost.classList.remove('visible');

    const postId = inputIdPost.value;
    const urlPost = 'https://jsonplaceholder.typicode.com/posts/' + postId;
    // console.log('urlPost:', urlPost)

    const xhr = ajaxInit(urlPost);

    xhr.addEventListener('load', e => {
        if (e.target.status === 200) {
            let response = e.target.responseText;

            try {
                const post = JSON.parse(response);
                fillArticleFromPost(post);

                fillUserInfoFromId(post.userId);

            } catch (error) {
                console.log('Error en la conversión:', error.message);
            }
        }
    });
});

function fillArticleFromPost (post) {
    articleTitle.innerHTML = post.title;
    articleBody.innerHTML = post.body;
    articleUserId.innerHTML = post.userId;
}

function fillUserInfoFromId(userId) {
    const urlUser = 'https://jsonplaceholder.typicode.com/users/' + userId;
    const xhrUser = ajaxInit(urlUser);
    xhrUser.addEventListener('load', e => {
        articlePost.classList.add('visible');
        if (e.target.status === 200) {
            console.log(e.target.responseText);
            try {
                const user = JSON.parse(e.target.responseText);
                // console.log('user:', user);
                // console.log('user.name:', user.name);
                articleUserId.innerHTML +=  ` (<a href="mailto:${user.email}">${user.name}</a>)`;
            } catch (error) {
                console.error('Upsss... algo falló!');
            }
        }
    });
}

function ajaxInit(url, method = 'get') {
    const xhr = new XMLHttpRequest();
    xhr.open(method, url);
    xhr.send();
    return xhr;
}