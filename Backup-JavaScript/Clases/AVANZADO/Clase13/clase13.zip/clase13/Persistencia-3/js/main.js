const promoElement = document.getElementById('promo');

let yaCerrado = sessionStorage.getItem('ya-cerrado');

if (!yaCerrado) {
    promoElement.classList.remove('display-none');
}

document.querySelector('.btn-close').addEventListener('click', e => {
    promoElement.classList.add('invisible');
    sessionStorage.setItem('ya-cerrado', 'Sí');
    setTimeout(e => {
        promoElement.classList.add('display-none');
    }, 3000);
});
