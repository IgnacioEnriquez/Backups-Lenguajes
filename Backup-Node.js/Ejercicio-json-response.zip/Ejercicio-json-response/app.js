
const products = [
    {   
        id: 101,
        price: 2600,
        title:'Funko Pop! Baby Sinclair',
    },

    {   
        id: 102,
        price:2600,
        title:'Funko Pop! Bob Esponja',
    },

    {   
        id: 103,
        price:2370,
        title:'Funko Pop! Dexter',
    },

    {   
        id: 104,
        price:2600,
        title:'Funko Pop! Jerry',
    },

    {   
        id: 105,
        price:2900,
        title:'Funko Pop! Sylvestre y Tweety',
    },

    {   
        id: 106,
        price:2830,
        title:'Funko Pop! Tortuga Ninja',
    },


    {   
        id: 107,
        price:2470,
        title:'Funko Pop! Dee Dee ',
    },

    {   
        id: 108,
        price:2600,
        title:'Funko Pop! Cat Dog',
    },

    {   
        id: 109,
        price:2850,
        title:'Funko Pop! Angelica Rugrats',
    },


    {   
        id: 110,
        price:2600,
        title:'Funko Pop! Hey Arnold',
    },

    {   
        id: 111,
        price:2480,
        title:'Funko Pop! Charmander Pokemon',
    },


    {   
        id: 112,
        price:3300,
        title:'Funko Pop! Pikachu Pokemon',
    },

    {   
        id: 113,
        price:35150,
        title:'Darth Vader LEGO®',
    },

    {   
        id: 114,
        price:4900,
        title:'Yoda Bebé Bag',
    },

    {   
        id: 115,
        price:7890,
        title:'Robot Star Wars Bb8',
    },

    {   
        id: 116,
        price:5100,
        title:'Soldado clon Star Wars',
    },

    {   
        id: 117,
        price:9950,
        title:' Obi-Wan Kenobi Star Wars',
    },

    {   
        id: 118,
        price:6300,
        title:'Monopoly Star Wars',
    },

    {   
        id: 119,
        price:32350,
        title:'Peluche Bebé Yoda',
    },

    {   
        id: 120,
        price:8600,
        title:'Espada láser Star Wars',
    },

    {   
        id: 121,
        price:124950,
        title:'Chewie - sonidos y movimiento',
    },

    {   
        id: 122,
        price:10680,
        title:'Soldado de Asalto LEGO®',
    },

    {   
        id: 123,
        img:"img/star-wars/star-wars-puzzles.png" ,
        price:4350,
        title:'Rompecabezas Star Wars',
    },

    {   
        id: 124,
        img:"img/star-wars/yoda-lego.PNG" ,
        price:32600,
        title:'Yoda LEGO®',
    },
]




/*

Generar, a partir del listado de productos, las respuestas JSON para las siguientes rutas, a partir del método GET.

/api/products
/api/products/101
/api/products/102
/api/products/103
/api/products/104
/api/products/105


*/

