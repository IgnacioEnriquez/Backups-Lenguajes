const express = require('express');

const app = express();

const customer1 = { firstName: 'Javier', lastName: 'Rodríguez', city: 'Rosario' };
const customer2 = { firstName: 'Lucía', lastName: 'Gutiérrez', city: 'San Miguel de Tucumán' };
const customer3 = { firstName: 'Viviana', lastName: 'García', city: 'Bariloche' };
const customers = [customer1, customer2, customer3];

app.get('/customers', (req, res) => {
    res.json(customers);    // array de objetos
});

app.get('/customers/1', (req, res) => {
    res.json(customer1);    // objeto
});

app.get('/customers/2', (req, res) => {
    res.json(customer2);    // objeto
});

app.get('/customers/3', (req, res) => {
    res.json(customer3);    // objeto
});

app.get('/company-info', (req, res) => {
    res.json({              // objeto
        id: 2,
        email: 'info@servicios.com',
        telephone: '(011) 4000-5000'
    });
});

app.get('*', (req, res) => {
    res.status(404).send(`<h1 style="background-color: #1fbf5f; color: #fff;">Recurso no encontrado</h1> <p>Fecha y hora: ${new Date().toLocaleString()} </p>`)
});


const PORT = 8080;
const server = app.listen(PORT, () => console.log(`Servidor Express escuchando en el puerto ${PORT}`));
server.on('error', error => console.error('Se produjo un error al intentar iniciar el servidor Express. Detalle: ' + error.message));
