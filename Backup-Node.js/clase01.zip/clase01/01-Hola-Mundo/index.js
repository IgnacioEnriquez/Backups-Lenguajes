console.log('Hola mundo!');
console.log('Esto es Node.js 🥳');
