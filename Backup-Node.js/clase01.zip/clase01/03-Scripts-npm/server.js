const saludo = 'Hola';
console.log(`${saludo}!`);

//  Ejemplos de uso de scripts de NPM:
// npm run nombre-script

// npm run test                     <-- funciona sin "run"
// npm test
// npm run start                    <-- funciona sin "run"
// npm start
// npm run mostrar-version-node
// npm run get-info