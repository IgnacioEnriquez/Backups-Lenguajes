// Servidor HTTP de Node.js
// https://nodejs.org/dist/latest-v18.x/docs/api/http.html

// Método createServer
// https://nodejs.org/dist/latest-v18.x/docs/api/http.html#httpcreateserveroptions-requestlistener

const http = require('http');

const server = http.createServer((req, res) => {
    console.log('Se recibió una petición HTTP.');
    const status = 200;
    res.writeHead(status, {
        // 'content-type': 'text/plain'
        'content-type': 'text/html; charset=utf-8',
        // 'otro-encabezado': 'otr-valor'
    });
    res.end(`
        <h1>Hola mundo!</h1>
        <p>Bienvenido al servidor HTTP de Node.js! 🥳</p>
    `);
});

const PORT = 8080;
server.listen(PORT, () => console.log(`Servidor HTTP escuchando en el puerto ${PORT}.`));
server.on('error', error => console.log(`Se produjo un error al intentar iniciar el servidor HTTP. ${error.message}.`));
