// Servidor HTTP de Node.js
// https://nodejs.org/dist/latest-v16.x/docs/api/http.html

// Método createServer
// https://nodejs.org/dist/latest-v16.x/docs/api/http.html#httpcreateserveroptions-requestlistener

const http = require('http');

const server = http.createServer((req, res) => {
    console.log('Se recibió una petición HTTP.');
    const status = 200;
    res.writeHead(status, {
        // 'content-type': 'text/plain'
        'content-type': 'text/html; charset=utf-8',
        // 'otro-encabezado': 'otr-valor'
    });
    // Respuesta completa, de una sola vez:
    // res.end(`
    //     <h1>Hola mundo!</h1>
    //     <p>Bienvenido al servidor HTTP de Node.js! 🥳</p>
    // `);
    res.write('<!DOCTYPE html>');
    res.write('<title> Respuesta de a poco...</title>');
    res.write('<style> body { color: #246; }</style>');
    res.write('<h1>Hola!</h1>');
    res.write(`<p>Inicio de la respuesta: ${new Date().toLocaleString()}</p>`);
    res.write(`\n<p>Esto es otro párrafo</p>`);
    res.write(`
        <ul>
            <li>Esta es una lista...</li>
            <li>... con algunos...</li>
            <li>... elemento.</li>
        </ul>
    `);
    setTimeout(() => res.write('<p>Este párrafo llegó 500ms después.</p>'), 500);
    setTimeout(() => res.write('<p>Y este llegó 500ms más tarde.</p>'), 1000);
    
    setTimeout(() => res.write('<p>Este es...'), 1500);
    setTimeout(() => res.write('...un mensaje...'), 2000);
    setTimeout(() => res.write('...que llega...'), 2500);
    setTimeout(() => res.write('...de a poco.</p>'), 3000);

    setTimeout(
        () => res.end(`<p>Fin de la respuesta: ${new Date().toLocaleString()}</p>`),
        3500
    );

});

const PORT = 8080;
server.listen(PORT, () => console.log(`Servidor HTTP escuchando en el puerto ${PORT}.`));
server.on('error', error => console.log(`Se produjo un error al intentar iniciar el servidor HTTP. ${error.message}.`));
