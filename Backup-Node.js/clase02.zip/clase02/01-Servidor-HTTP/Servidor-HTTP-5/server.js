// Servidor HTTP de Node.js
// https://nodejs.org/dist/latest-v16.x/docs/api/http.html

// Método createServer
// https://nodejs.org/dist/latest-v16.x/docs/api/http.html#httpcreateserveroptions-requestlistener

const http = require('http');

let visitorCounter = 0;

const server = http.createServer((req, res) => {
    // const method = req.method;
    // const url = req.url;
    const {method, url} = req;
    console.log(`${new Date().toLocaleString()} | ${method} | ${url}`);
    
    const status = 200;
    res.writeHead(status, { 'content-type': 'text/html; charset=utf-8' });

    res.write('<h1>Hola!</h1>');
    res.write(`<p>Inicio de la respuesta: ${new Date().toLocaleString()}</p>`);

    // Para que no cuenta el request del favicon.ico que algunos navegadores generan.
    if (url !== '/favicon.ico') {
        visitorCounter++;
        res.write(`<p>Cantidad de visitas: ${visitorCounter}</p>`);
    }

    res.end(`\n<p>Esto es otro párrafo</p>`);

    
});

const PORT = 8080;
server.listen(PORT, () => console.log(`Servidor HTTP escuchando en el puerto ${PORT}.`));
server.on('error', error => console.log(`Se produjo un error al intentar iniciar el servidor HTTP. ${error.message}.`));
