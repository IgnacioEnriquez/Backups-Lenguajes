// Servidor HTTP de Node.js
// https://nodejs.org/dist/latest-v16.x/docs/api/http.html

// Método createServer
// https://nodejs.org/dist/latest-v16.x/docs/api/http.html#httpcreateserveroptions-requestlistener

const http = require('http');

let visitorCounter = 0;
const nav = `
    <nav>
        <a href="/">Inicio</a> -
        <a href="/productos">Productos</a> -
        <a href="/servicios">Servicios</a> -
        <a href="/reset">Reseteo</a> -
        <a href="/url-que-no-existe">Inexistente</a>
    </nav>
`;

const server = http.createServer((req, res) => {
    // const method = req.method;
    // const url = req.url;
    const {method, url} = req;
    console.log(`${new Date().toLocaleString()} | ${method} | ${url}`);

    if (method === 'GET') {

        visitorCounter++;
        
        if (url === '/') {
            const status = 200;
            res.writeHead(status, { 'content-type': 'text/html; charset=utf-8' });
            res.write(nav);
            res.write('<h1>Hola!</h1>');
            res.write(`<p>Inicio de la respuesta: ${new Date().toLocaleString()}</p>`);
            res.end(`<p>Cantidad de visitas: ${visitorCounter}</p>`);
        } else if (url === '/reset') {
            res.writeHead(200, { 'content-type': 'text/html; charset=utf-8'});
            res.write(nav);
            visitorCounter = 0;
            res.end('<h1>Contador de visitas reiniciado.</h1>');
        } else if (url === '/productos') {
            res.writeHead(200, { 'content-type': 'text/html; charset=utf-8'});
            res.write(nav);
            res.end('<h1>Productos</h1> <p>Estos son nuestros productos...</p>');
        } else if (url === '/servicios') {
            res.writeHead(200, { 'content-type': 'text/html; charset=utf-8'});
            res.write(nav);
            res.end(`
            <h1>Nuestros servicios</h1>
            <h2>Servicio 1</h2>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
            <h2>Servicio 2</h2>
            <p>Vitae, distinctio sit blanditiis officia ab eaque accusantium et.</p>
            <h2>Agregar servicio</h2>
            <form action="/alta-servicio" method="post">
                <label for="nombre">Nombre</label>
                <input name="nombre" id="nombre" autofocus>
                <input type="submit" value="Agregar">
            </form>
            `);
        } else {
            res.writeHead(404, { 'content-type': 'text/html; charset=utf-8' });
            res.write(nav);
            res.end(`
                <h1 style="color: #a22;">Error 404 - Recurso no encontrado</h1>
                <p>URL solicitada: ${url}</p>
            `);
        }
    } else if (method === 'POST') {
        if (url === '/alta-servicio') {
            res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
            res.end('<h1>Servicio dado de alta con éxito</h1>');
        } else {
            res.writeHead(404, { 'content-type': 'text/html; charset=utf-8' });
            res.write(nav);
            res.end(`
                <h1 style="color: #a22;">Error 404 - Recurso no encontrado para el método POST.</h1>
                <p>URL solicitada: ${url}</p>
            `);
        }
    } else {
        // https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/405
        // https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Allow
        res.writeHead(405, {
            'content-type': 'text/html; charset=utf-8',
            'allow': 'GET'
        });
        res.end(`
            <h1>Error</h1>
            <p>Método ${method} no implemnetado para este recurso.</p>
            <p>URL solicitada: ${url}</p>
        `);
    }
});

const PORT = 8080;
server.listen(PORT, () => console.log(`Servidor HTTP escuchando en el puerto ${PORT}.`));
server.on('error', error => console.log(`Se produjo un error al intentar iniciar el servidor HTTP. ${error.message}.`));
