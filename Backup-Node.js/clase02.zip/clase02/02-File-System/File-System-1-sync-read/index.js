/*
fs nos permite leer/escribir archivos, entre otras cosas.
Está disponible internamente, sin necesidad de instalarla.
*/

const fs = require('fs');

const fileName = 'datos.txt';
const charset = 'utf-8';

// readFileSync permite leer un archivo de forma sincrónica
// let currentContent = fs.readFileSync(fileName);
let currentContent = fs.readFileSync(fileName, charset);
console.log('Contenido actual del archivo:', currentContent);
