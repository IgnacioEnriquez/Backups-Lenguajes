/*
fs nos permite leer/escribir archivos, entre otras cosas.
Está disponible internamente, sin necesidad de instalarla.
*/

const fs = require('fs');

const fileName = 'datos.txt';
// const fileName = 'ARCHIVO-INEXISTENTE.txt';
const charset = 'utf-8';

console.log('Antes de programar la manipulación del archivo.');

// PROBLEMA: Ejecución de callbacks de forma desordenada:
// fs.readFile(fileName, charset, (error, data) => {
//     if (error) {
//         console.error('Se produjo un error al intentar leer el archivo.');
//         return;
//     }
//     console.log('Contenido actual del archivo: ', data);
// });
// 
// fs.writeFile(fileName, new Date().toLocaleString(), error => {
//     if (error) {
//         console.error('Se produjo un error al intentar escribir el archivo.');
//         return;
//     }
//     console.log('Archivo escrito OK');
// });
// 
// fs.readFile(fileName, charset, (error, data) => {
//     if (error) {
//         console.error('Se produjo un error al intentar leer el archivo.');
//         return;
//     }
//     console.log('Nuevo contenido del archivo: ', data);
// });

// Ordenamiento de la ejecución de callbacks mediante
// el anidamiento de callbacks
// Problema: callbacks hell o pyramid of doom
fs.readFile(fileName, charset, (error, data) => {
    if (error) {
        console.error('Se produjo un error al intentar leer el archivo.');
        return;
    }
    console.log('Contenido actual del archivo: ', data);

    fs.writeFile(fileName, new Date().toLocaleString(), error => {
        if (error) {
            console.error('Se produjo un error al intentar escribir el archivo.');
            return;
        }
        console.log('Archivo escrito OK');

        fs.readFile(fileName, charset, (error, data) => {
            if (error) {
                console.error('Se produjo un error al intentar leer el archivo.');
                return;
            }
            console.log('Nuevo contenido del archivo: ', data);
        });

    });

});

console.log('Después de programar la manipulación del archivo.');
