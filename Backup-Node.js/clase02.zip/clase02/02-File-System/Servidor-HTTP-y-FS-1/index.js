const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    
    const {method, url} = req;
    console.log(`${new Date().toLocaleString()} - ${method} - ${url}`);

    if (method === 'GET') {

        const dirPath = 'public';

        // TODO: Reemplazar el condicional por una expresión regular.
        if (url === '/' || url === '/index' || url === '/index.html') {

            const filePath = dirPath + '/index.html';

            fs.readFile(filePath, 'utf-8', (error, page) => {
                if (error) {
                    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#server_error_responses
                    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/500
                    res.writeHead(500, {
                        'content-type': 'text/html; charset=utf-8'
                    });
                    res.end(
                        `
                            <h1 style="color: #722;">Error 500</h1>
                            <p>Recurso no encontrado: [${method}] ${url}</p>
                        `
                    );
                    console.error('Archivo no encontrado: ' + filePath);
                    return;
                }

                res.writeHead(200, {'content-type': 'text/html; charset=utf-8'});
                res.end(page);

            });

            // res.writeHead(200, {
            //     'content-type': 'text/html; charset=utf-8'
            // });
            // res.end('<p>Contenido del archivo.</p>');

        } else if (url === '/contacto.html') {

            const filePath = dirPath + '/contacto.html';

            fs.readFile(filePath, 'utf-8', (error, page) => {
                if (error) {
                    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#server_error_responses
                    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/500
                    res.writeHead(500, {
                        'content-type': 'text/html; charset=utf-8'
                    });
                    res.end(
                        `
                            <h1 style="color: #722;">Error 500</h1>
                            <p>Recurso no encontrado: [${method}] ${url}</p>
                        `
                    );
                    console.error('Archivo no encontrado: ' + filePath);
                    return;
                }

                res.writeHead(200, {'content-type': 'text/html; charset=utf-8'});
                res.end(page);

            });

            // res.writeHead(200, {
            //     'content-type': 'text/html; charset=utf-8'
            // });
            // res.end('<p>Contenido del archivo.</p>');

        } else {
            res.writeHead(404, { 'content-type': 'text/html; charset=utf-8' });
            res.end(
                `
                    <h1 style="color: #722;">Error 404</h1>
                    <p>Recurso no encontrado: ${url}</p>
                    <p>Estás perdido? <a href="/">Volvé a la home!</a></p>
                `
            );
    
        }
    } else {
        res.writeHead(405, {
            'content-type': 'text/html; charset=utf-8',
            'allow': 'GET'
        });
        res.end(
            `
                <h1 style="color: #722;">Error 405</h1>
                <p>
                    El método ${method} no está implementado para la URL solicitada: ${url}
                </p>
            `
        );
    }
});

const PORT = 8080;

server.listen(PORT, () => console.log(`Servidor HTTP escuchando en el puerto ${PORT}.`));

server.on('error', error => console.log('No fue posible iniciar el servidor HTTP. Detalle: ' + error.message));
