console.log('Hola!');
const h1 = document.querySelector('h1');
if (h1) {
    h1.innerHTML = ':: ' + h1.innerHTML + ' ::';
}
