const express = require('express');
console.log('express:', express);

const app = express();

// No fue necesario especificar los encabezados
// Tampoco el status 200
// Además, las URL no definidas generar un error.

app.get('/', (req, res) => {
    res.send('<h1>Hola mundo!</h1> <p>Respuesta generada desde Express</p>');
});

const PORT = 8080;
const server = app.listen(PORT, () => console.log(`Servidor Express escuchando en el puerto ${PORT}`));
server.on('error', error => console.error('Se produjo un error al intentar iniciar el servidor Express. Detalle: ' + error.message));
