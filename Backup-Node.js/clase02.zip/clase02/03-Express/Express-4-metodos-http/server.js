const express = require('express');

const app = express();

let visitorCounter = 0;

/////////////////////
//    RUTAS GET    //
/////////////////////

// No fue necesario especificar los encabezados
// Tampoco el status 200
// Además, las URL no definidas generar un error.

// Si está antes que las otras, responde esta siempre
// app.get('*', (req, res) => {
//     res.send('<h1>*</h1>');
// });

app.get('/', (req, res) => {
    res.send('<h1>Hola mundo!</h1> <p>Respuesta generada desde Express</p>');
    visitorCounter++;
});

app.get('/contador', (req, res) => {
    res.send(`<h1>Contador</h1> <p>Cantidad de visitas a la página de inicio: ${visitorCounter}</p>`);
});

app.get('/reset', (req, res) => {
    visitorCounter = 0;
    res.send(`<h1>Contador reseteado</h1> <p><a href="/">Ir a la página de inicio</a></p>`);
});

app.get('/prueba-metodo', (req, res) => {
    const {method} = req;
    res.send(`<h1 style="background-color: #1fbf5f; color: #fff;">Acceso por método ${method}</h1>`);
});

app.get('/prueba*', (req, res) => {
    const {url} = req;
    res.send(`
        <h1>/prueba*</h1>
        <p>URL solicitada: ${url}</p>
    `);
});

app.get('/*.html', (req, res) => {
    const {url} = req;
    res.send(`
        <h1>/*.html</h1>
        <p>URL solicitada: ${url}</p>
    `);
});

app.get('/*.css', (req, res) => {
    const {url} = req;
    // res.setHeader('content-type', 'text/css; charset=utf-8');
    // res.send(`body { }`);
    res.setHeader('content-type', 'text/css; charset=utf-8').send(
        `
            /* URL: ${url} */
            body { }
        `)
    ;
});

app.get('/a*2', (req, res) => {
    const {url} = req;
    res.send(`
    <h1>/a*2</h1>
    <p>URL solicitada: ${url}</p>
    `);
});

app.get('*', (req, res) => {
    res.status(404).send(`<h1 style="background-color: #1fbf5f; color: #fff;">Recurso no encontrado</h1> <p>Fecha y hora: ${new Date().toLocaleString()} </p>`)
});

//////////////////////
//    RUTAS POST    //
//////////////////////

app.post('/prueba-metodo', (req, res) => {
    const {method} = req;
    res.send(`<h1 style="background-color: #fcbd25; color: #fff;">Acceso por método ${method}</h1>`);
});

app.post('*', (req, res) => {
    const {url} = req;
    res.status(404).send(`
        <h1 style="background-color: #fcbd25; color: #fff;">Recurso no encontrado</h1>
        <p>URL solicitada: ${url}</p>
    `);
});

/////////////////////
//    RUTAS PUT    //
/////////////////////

app.put('/prueba-metodo', (req, res) => {
    const {method} = req;
    res.send(`<h1 style="background-color: #4a9ced; color: #fff;">Acceso por método ${method}</h1>`);
});

app.put('*', (req, res) => {
    const {url} = req;
    res.status(404).send(`
        <h1 style="background-color: #4a9ced; color: #fff;">Recurso no encontrado</h1>
        <p>URL solicitada: ${url}</p>
    `);
});

////////////////////////
//    RUTAS DELETE    //
////////////////////////

app.delete('/prueba-metodo', (req, res) => {
    const {method} = req;
    res.send(`<h1 style="background-color: #ec7069; color: #fff;">Acceso por método ${method}</h1>`);
});

app.delete('*', (req, res) => {
    const {url} = req;
    res.status(404).send(`
        <h1 style="background-color: #ec7069; color: #fff;">Recurso no encontrado</h1>
        <p>URL solicitada: ${url}</p>
    `);
});


const PORT = 8080;
const server = app.listen(PORT, () => console.log(`Servidor Express escuchando en el puerto ${PORT}`));
server.on('error', error => console.error('Se produjo un error al intentar iniciar el servidor Express. Detalle: ' + error.message));
