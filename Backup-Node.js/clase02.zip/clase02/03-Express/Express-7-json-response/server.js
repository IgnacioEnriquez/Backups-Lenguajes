const express = require('express');

const app = express();

app.get('/', (req, res) => {
    res.json({
        id: 2,
        email: 'info@servicios.com',
        telephone: '(011) 4000-5000'
    });
});

app.get('*', (req, res) => {
    res.status(404).send(`<h1 style="background-color: #1fbf5f; color: #fff;">Recurso no encontrado</h1> <p>Fecha y hora: ${new Date().toLocaleString()} </p>`)
});


const PORT = 8080;
const server = app.listen(PORT, () => console.log(`Servidor Express escuchando en el puerto ${PORT}`));
server.on('error', error => console.error('Se produjo un error al intentar iniciar el servidor Express. Detalle: ' + error.message));
