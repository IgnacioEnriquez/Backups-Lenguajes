const express = require('express');

const app = express();

app.get('/producto/:id', (req, res) => {
    const {id} = req.params;

    let product = {};
    switch (id) {
        case '1':
            product = {id: 1, name: 'TV', brand: 'Sony', price: 94200};
            break;
        case '2':
            product = {id: 1, name: 'Microondas', brand: 'BGH', price: 48500};
            break;
        case '3':
            product = {id: 3, name: 'Equipo de música', brand: 'Sony', price: 61800};
            break;
        default:
            // res.sendStatus(418); // I'm a Teapod
            res.sendStatus(418);
            // res.status(404).send('<h1>Producto no encontrado</h1>');
            return;
    }
    res.send(
        `
            <h1>${product.name} ${product.brand}</h1>
            <p>Id: ${product.id}</p>
            <p>Precio: $${product.price}</p>
        `
    );
});

app.get('*', (req, res) => {
    res.status(404).send(`<h1 style="background-color: #1fbf5f; color: #fff;">Recurso no encontrado</h1> <p>Fecha y hora: ${new Date().toLocaleString()} </p>`)
});


const PORT = 8080;
const server = app.listen(PORT, () => console.log(`Servidor Express escuchando en el puerto ${PORT}`));
server.on('error', error => console.error('Se produjo un error al intentar iniciar el servidor Express. Detalle: ' + error.message));
